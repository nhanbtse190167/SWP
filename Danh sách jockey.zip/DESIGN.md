---
name: Equine Prestige
colors:
  surface: '#fbf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#404942'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#717971'
  outline-variant: '#c0c9c0'
  surface-tint: '#316948'
  primary: '#002a15'
  on-primary: '#ffffff'
  primary-container: '#004225'
  on-primary-container: '#75af89'
  inverse-primary: '#98d4ac'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#212424'
  on-tertiary: '#ffffff'
  tertiary-container: '#373939'
  on-tertiary-container: '#a1a2a2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b4f0c7'
  primary-fixed-dim: '#98d4ac'
  on-primary-fixed: '#002110'
  on-primary-fixed-variant: '#165132'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  display-lg:
    fontFamily: Domine
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Domine
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Domine
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Domine
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-tabular:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 4px
  stack-md: 12px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for a premium horse racing experience, targeting high-stakes enthusiasts and casual fans who appreciate the sport's heritage. The brand personality is **authoritative, prestigious, and high-octane**. It balances the weight of a traditional sporting institution with the adrenaline of live betting.

The visual style is **Corporate / Modern** with **Tactile** influences. It utilizes clean layouts and structural integrity, punctuated by elegant lines and subtle turf-inspired textures to ground the digital experience in the physical reality of the track. The UI must feel expensive, reliable, and fast, evoking the same emotional response as standing trackside at a championship event. High-contrast action photography should be treated with subtle vignettes to ensure UI overlays remain legible while maintaining a cinematic quality.

## Colors

The palette is rooted in the heritage of the turf. **Deep Racing Green** serves as the primary anchor, used for headers, primary actions, and brand-heavy surfaces to establish authority. **Trophy Gold** is our accent of excellence, reserved for "Win" indicators, premium tiers, and critical highlights.

The neutral system uses **Crisp White** for main surfaces to maintain a clean, professional aesthetic, while **Charcoal Gray** (#333333) provides high-legibility typography. For data-heavy race cards, a series of light cool-gray washes (#F4F7F5) should be used to differentiate rows without breaking the clean aesthetic.

## Typography

This design system utilizes a sophisticated typographic pairing to signal both tradition and precision. **Domine** is used for all headlines; its sturdy, authoritative serif strokes provide the "literary" feel of a racing program. 

**Hanken Grotesk** handles all functional data and body copy. It was chosen for its sharp, contemporary geometry which ensures maximum legibility in high-density race cards and odds displays. For numerical data, always enable tabular lining figures to ensure odds and times align perfectly in vertical columns. Use `label-caps` for table headers and metadata to provide clear hierarchy without competing with primary data points.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop to maintain a prestigious, editorial feel, transitioning to a fluid model on mobile devices. A 12-column grid is standard for desktop, while a 4-column grid is used for mobile.

Spacing follows an 8px rhythmic scale. High-density areas like race cards utilize tighter vertical spacing (`stack-sm`) to maximize information density, while editorial sections and landing pages utilize generous white space (`stack-lg`) to evoke a luxury experience. Gutters are kept wide at 24px to prevent data-heavy columns from feeling cluttered.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Low-contrast outlines**. We avoid heavy, muddy shadows to maintain a "Crisp White" aesthetic. 

- **Level 0 (Surface):** The main background, typically Crisp White or a very subtle gray.
- **Level 1 (Cards):** Use a 1px border in a light gray (#E0E0E0) with no shadow.
- **Level 2 (Interactive):** When a race card or odds button is hovered, apply a subtle, highly-diffused Racing Green tinted shadow (0px 4px 20px rgba(0, 66, 37, 0.08)).
- **Level 3 (Modals/Overlays):** Use a slightly stronger shadow and a 2px Trophy Gold top-accent border to signify premium importance.

## Shapes

The design system employs **Soft** roundedness. A standard radius of 4px (`0.25rem`) is applied to buttons, input fields, and small UI components. This subtle rounding removes the harshness of pure geometric squares while maintaining a disciplined, professional appearance. 

Larger containers like Race Cards may use a 8px radius (`rounded-lg`) to feel more approachable, but under no circumstances should pill-shaped buttons or hyper-rounded "bubbles" be used, as they detract from the authoritative nature of the sport.

## Components

### Race Cards & Odds
Race cards are the core component. They should use a horizontal layout with a "Jersey" icon for the jockey, the horse name in `headline-md`, and secondary stats in `data-tabular`. Odds buttons should be large, clear, and use a Trophy Gold background (#D4AF37) with Charcoal text to indicate they are the primary interaction point.

### Live Status Indicators
Live indicators (e.g., "GATES OPEN", "LIVE") should use a pulsing animation and high-contrast background. Use Racing Green for "Finished" and a vibrant crimson for "Live" to command attention.

### Navigation
The main navigation should be grounded in Deep Racing Green. Links should use `label-caps` in White, with a Trophy Gold underline (2px) appearing on hover or active states. 

### Input Fields
Fields should be minimalist with a 1px Charcoal border. On focus, the border transitions to Racing Green. Labels should always be visible above the field using `label-caps` for a professional, "form-like" feel.

### Action Buttons
- **Primary:** Deep Racing Green background, White text, 4px border-radius.
- **Secondary:** Transparent background, 1px Racing Green border, Racing Green text.
- **Premium/Win:** Trophy Gold background, Charcoal text (reserved for "Place Bet" or "Upgrade").